import csv
import random
import datetime

def map_ton_iot_dataset(input_file, output_file, max_rows=500):
    print(f"Mapping ToN_IoT dataset from {input_file} to CyberScope 7D schema...")
    
    mapped_rows = []
    headers = [
        "sensor_id", "temperature", "voltage", "cpu_util", 
        "free_heap", "packet_drop", "i2c_faults", "network_traffic", "timestamp"
    ]
    
    try:
        with open(input_file, mode='r', encoding='utf-8') as infile:
            reader = csv.DictReader(infile)
            
            for index, row in enumerate(reader):
                if index >= max_rows: # Limit to 500 rows for a quick test
                    break
                    
                # Extract ToN_IoT network metrics (Fallback to random if column names differ slightly)
                src_bytes = int(row.get('src_bytes', random.randint(100, 5000)))
                dst_bytes = int(row.get('dst_bytes', random.randint(100, 5000)))
                real_traffic_kbs = (src_bytes + dst_bytes) / 1024.0
                
                # Check if it's an attack (ToN_IoT usually uses 'label' where 1 = attack)
                is_attack = str(row.get('label', '0')) == '1'
                
                # Synthesize the hardware metrics based on the attack label
                if is_attack:
                    temp = random.uniform(85.0, 98.0)      # High heat
                    volt = random.uniform(4.8, 5.5)        # Voltage spike
                    cpu = random.uniform(85.0, 99.0)       # CPU pegged
                    heap = random.uniform(10.0, 45.0)      # Memory exhausted
                    drop = random.uniform(15.0, 35.0)      # High packet drop
                    faults = random.randint(5, 12)
                else:
                    temp = random.uniform(28.0, 35.0)
                    volt = random.uniform(3.2, 3.4)
                    cpu = random.uniform(15.0, 35.0)
                    heap = random.uniform(210.0, 260.0)
                    drop = random.uniform(0.0, 1.5)
                    faults = 0
                
                mapped_rows.append({
                    "sensor_id": f"TON-IOT-NODE-{index % 3 + 1}",
                    "temperature": round(temp, 2),
                    "voltage": round(volt, 2),
                    "cpu_util": round(cpu, 2),
                    "free_heap": round(heap, 2),
                    "packet_drop": round(drop, 2),
                    "i2c_faults": faults,
                    "network_traffic": round(real_traffic_kbs, 2),
                    "timestamp": datetime.datetime.now().isoformat()
                })
                
        with open(output_file, mode='w', encoding='utf-8', newline='') as outfile:
            writer = csv.DictWriter(outfile, fieldnames=headers)
            writer.writeheader()
            writer.writerows(mapped_rows)
            
        print(f"Success! Mapped {len(mapped_rows)} rows to {output_file}.")
        print("Upload this file into the CyberScope Log Analyzer.")

    except FileNotFoundError:
        print(f"Error: Could not find {input_file}. Ensure it is in the correct directory.")

if __name__ == "__main__":
    map_ton_iot_dataset("raw_dataset.csv", "mapped_real_world_test.csv")