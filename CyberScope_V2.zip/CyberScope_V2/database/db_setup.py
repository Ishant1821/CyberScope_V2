import os
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash

db = SQLAlchemy()

class Incident(db.Model):
    __tablename__ = 'incidents'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sensor_id = db.Column(db.String(50))
    temperature = db.Column(db.Float)
    voltage = db.Column(db.Float)
    cpu_util = db.Column(db.Float)
    free_heap = db.Column(db.Float)
    packet_drop = db.Column(db.Float)
    i2c_faults = db.Column(db.Integer)
    network_traffic = db.Column(db.Float)
    timestamp = db.Column(db.String(50))
    classification = db.Column(db.String(255))

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

def init_db(app, admin_user=None, admin_pass=None):
    with app.app_context():
        db.create_all()
        
        if admin_user and admin_pass:
            hashed_pw = generate_password_hash(admin_pass)
            user = User.query.filter_by(username=admin_user).first()
            if user:
                user.password_hash = hashed_pw
            else:
                user = User(username=admin_user, password_hash=hashed_pw)
                db.session.add(user)
            db.session.commit()
        else:
            user = User.query.filter_by(username='admin').first()
            if not user:
                hashed_pw = generate_password_hash('admin123')
                user = User(username='admin', password_hash=hashed_pw)
                db.session.add(user)
                db.session.commit()

def log_incident(sensor_id, temp, volt, cpu, heap, drop, faults, traffic, timestamp, classification):
    incident = Incident(
        sensor_id=sensor_id, temperature=temp, voltage=volt, 
        cpu_util=cpu, free_heap=heap, packet_drop=drop, 
        i2c_faults=faults, network_traffic=traffic, 
        timestamp=timestamp, classification=classification
    )
    db.session.add(incident)
    db.session.commit()

def get_incidents():
    incidents = Incident.query.all()
    # Return as tuples to maintain compatibility with existing Jinja templates
    return [(i.id, i.sensor_id, i.temperature, i.voltage, i.cpu_util, 
             i.free_heap, i.packet_drop, i.i2c_faults, i.network_traffic, 
             i.timestamp, i.classification) for i in incidents]

def clear_incidents():
    Incident.query.delete()
    db.session.commit()

def get_user_by_username(username):
    user = User.query.filter_by(username=username).first()
    if user:
        return (user.id, user.username, user.password_hash)
    return None

def get_user_by_id(user_id):
    user = User.query.get(int(user_id))
    if user:
        return (user.id, user.username, user.password_hash)
    return None