import joblib
import os
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

os.makedirs('models', exist_ok=True)

# Generate 7D normal operational bounds
# Increased training size from 500 to 5000 for a more stable baseline
# Columns: Temp, Volt, CPU, Heap, Drop, Faults, Traffic
normal_data = np.random.normal(
    loc=[30.0, 3.3, 20.0, 240.0, 0.2, 0.0, 30.0], 
    scale=[3.0, 0.15, 5.0, 15.0, 0.1, 0.01, 10.0], 
    size=(5000, 7)
)

# Wrap the scaler and the model in a Pipeline
# - StandardScaler ensures all 7 dimensions are weighted equally
# - n_estimators=300 stabilizes the isolation trees
# - contamination=0.01 severely reduces the false positive rate
model_pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('iso_forest', IsolationForest(n_estimators=300, contamination=0.01, random_state=42, n_jobs=-1))
])

model_pipeline.fit(normal_data)

joblib.dump(model_pipeline, 'models/anomaly_model.pkl')
print("7-Dimensional Model Pipeline (Scaler + iForest) retrained successfully!")